/* ============================================================
   Портфолио — Кирилл Скориков
   Данные, i18n, рендер, темы, язык, лайтбокс
   Стиль: zkPass (dark editorial + signal lime)
   ============================================================ */

const PROJECTS = [
  {
    id: "paradox-party",
    url: "",
    shots: [
      "assets/shots/design1.jpg",
      "assets/shots/design2.jpg",
      "assets/shots/design3.jpg",
      "assets/shots/design4.jpg",
      "assets/shots/design5.jpg",
      "assets/shots/design6.jpg"
    ],
    cover: [0, 3, 4], // какие постеры показывать на карточке
    owner: "Paradox Party · 19.09",
    ru: {
      cat: "Дизайн · Постеры",
      title: "Paradox Party — промо для посвята",
      desc: "Серия из шести постеров для студенческого посвята в стилистике Хеллоуина: пресейл, гивевей, преимущества, обратный отсчёт. Красно-чёрная палитра, зернистая фактура и узкий гротеск. Откройте карточку и листайте.",
    },
    en: {
      cat: "Design · Posters",
      title: "Paradox Party — freshman party promo",
      desc: "A set of six Halloween-style posters for a student party: presale, giveaway, perks, countdown. Red-and-black palette, grainy texture and a condensed grotesque. Open the card and scroll.",
    },
    tags: ["Дизайн", "Постеры", "Promo"],
  },

  {
    id: "vectorone",
    url: "https://vectorone.site",
    shot: "assets/shots/vectorone.jpg",
    owner: "ИП Курбетьева Э. А.",
    ru: {
      cat: "Корпоративный сайт",
      title: "VectorOne — сопровождение бизнеса",
      desc: "Сайт компании, объединяющей разработку ПО, юридические и бухгалтерские услуги в едином деловом контуре. Строгая типографика и уверенный деловой тон.",
    },
    en: {
      cat: "Corporate site",
      title: "VectorOne — business support",
      desc: "Site for a company that combines software development, legal and accounting services under one roof. Editorial typography and a confident business tone.",
    },
    tags: ["HTML", "CSS", "JavaScript", "Responsive"],
  },
  {
    id: "business-service",
    url: "https://business-service.site",
    shot: "assets/shots/business-service.jpg",
    owner: "ИП Борисенко А. В.",
    ru: {
      cat: "Сервисный сайт",
      title: "Business Service — решения для бизнеса",
      desc: "Многостраничный сайт услуг: от разработки ПО и 1С до логистики и техподдержки. Тёплая бежевая тема и подробный, аккуратно организованный каталог.",
    },
    en: {
      cat: "Services site",
      title: "Business Service — solutions for business",
      desc: "Multi-page services site: from software and 1C to logistics and support. Warm beige theme and a detailed, neatly organised catalogue.",
    },
    tags: ["HTML", "CSS", "JavaScript", "Multi-page"],
  },
  {
    id: "pro100buh",
    url: "https://pro100buh.ru",
    shot: "assets/shots/pro100buh.jpg",
    owner: "ИП Скориков А. А.",
    ru: {
      cat: "Сайт-сервис",
      title: "Pro100Buh — бухгалтерия и аудит",
      desc: "Сайт бухгалтерской практики с калькуляторами, справочниками и статьями. Тёмная тема с золотым акцентом и встроенные интерактивные инструменты.",
    },
    en: {
      cat: "Service platform",
      title: "Pro100Buh — accounting & audit",
      desc: "Accounting practice site with calculators, reference guides and articles. Dark theme with a gold accent and built-in interactive tools.",
    },
    tags: ["HTML", "CSS", "JavaScript", "Калькуляторы"],
  },
  {
    id: "maxlawyer",
    url: "https://maxlawyer.site",
    shot: "assets/shots/maxlawyer.jpg",
    owner: "ИП Максименко Н. А.",
    ru: {
      cat: "Лендинг",
      title: "Law-Legal — юридические услуги",
      desc: "Лендинг юридической практики: банкротство, корпоративные споры, представительство в судах и тендеры. Сдержанная шалфейная палитра и ясная структура.",
    },
    en: {
      cat: "Landing page",
      title: "Law-Legal — legal services",
      desc: "Legal practice landing: bankruptcy, corporate disputes, court representation and tenders. A restrained sage palette and a clear structure.",
    },
    tags: ["HTML", "CSS", "JavaScript", "Responsive"],
  },
  {
    id: "cargomove",
    url: "https://cargomove.site",
    shot: "assets/shots/cargomove.jpg",
    owner: "ИП Борисенко Д. В.",
    ru: {
      cat: "Лендинг",
      title: "CargoMove — спецтехника и сервис",
      desc: "Сайт услуг для бизнеса: аренда спецтехники, склад, погрузочные работы и ремонт оборудования. Мягкие карточки и модальные окна с деталями услуг.",
    },
    en: {
      cat: "Landing page",
      title: "CargoMove — equipment & service",
      desc: "Business services site: equipment rental, warehousing, loading works and repairs. Soft cards and modal windows with service details.",
    },
    tags: ["HTML", "CSS", "JavaScript", "Modals"],
  },
  {
    id: "gruzilovo",
    url: "https://gruzilovo.site",
    shot: "assets/shots/gruzilovo.jpg",
    owner: "ИП Игнатьев М. С.",
    ru: {
      cat: "Лендинг",
      title: "Грузилово — логистика и склад",
      desc: "Лендинг по складской обработке, погрузочно-разгрузочным работам и фулфилменту. Крупный герой-блок, карточки услуг и понятная навигация по процессу.",
    },
    en: {
      cat: "Landing page",
      title: "Gruzilovo — logistics & warehousing",
      desc: "Landing for warehouse handling, loading works and fulfilment. A bold hero block, service cards and clear navigation through the process.",
    },
    tags: ["HTML", "CSS", "JavaScript", "Responsive"],
  },
  {
    id: "logiconnect",
    url: "https://logiconnect.ru",
    shot: "assets/shots/logiconnect.jpg",
    owner: "ИП Игнатов Е. П.",
    ru: {
      cat: "Лендинг",
      title: "LogiConnect — импорт и логистика",
      desc: "Сопровождение импорта, досмотров и складской логистики под ключ. Спокойная сине-стальная гамма и акцент на прозрачности каждого этапа.",
    },
    en: {
      cat: "Landing page",
      title: "LogiConnect — import & logistics",
      desc: "Turnkey support for imports, inspections and warehouse logistics. A calm steel-blue palette with a focus on transparency at every stage.",
    },
    tags: ["HTML", "CSS", "JavaScript", "Responsive"],
  },
];

const I18N = {
  ru: {
    "nav.works": "Работы",
    "nav.about": "Обо мне",
    "nav.contact": "Контакты",
    "hero.status": "Открыт к проектам",
    "hero.eyebrow": "Frontend · Разработка сайтов",
    "hero.role": "Frontend-разработчик",
    "hero.lead": "Делаю лендинги и сайты для бизнеса на чистом HTML, CSS и JavaScript — быстрые, адаптивные и без лишнего.",
    "hero.cta1": "Смотреть работы",
    "hero.cta2": "Написать",
    "hero.stat1": "проектов в портфолио",
    "hero.stat2": "живых сайта в проде",
    "hero.stat3": "чистый стек",
    "works.eyebrow": "Избранные проекты",
    "works.index": "Индекс",
    "works.title": "Живые сайты, которые я сделал",
    "works.sub": "Семь живых сайтов для бизнеса и серия промо-постеров для студенческого посвята. Нажмите на карточку, чтобы посмотреть крупнее.",
    "works.open": "Открыть сайт",
    "works.view": "Смотреть дизайн",
    "about.eyebrow": "Обо мне",
    "about.index": "Профиль",
    "about.title": "Коротко о работе",
    "about.lead": "Я делаю чистые, быстрые и адаптивные сайты на HTML, CSS и JavaScript — без тяжёлых фреймворков и лишнего.",
    "about.text": "Специализируюсь на лендингах и сервисных сайтах для бизнеса: от идеи и структуры до вёрстки, анимаций и публикации на боевом домене. Уделяю внимание типографике, скорости загрузки и тому, чтобы сайт одинаково хорошо смотрелся на телефоне и на десктопе.",
    "about.spec": "Навыки",
    "about.s1": "Вёрстка (HTML / CSS)",
    "about.s2": "JavaScript",
    "about.s3": "Адаптив и анимации",
    "about.s4": "Публикация и домены",
    "contact.eyebrow": "Контакты",
    "contact.title": "Давайте сделаем сайт",
    "contact.sub": "Нужен лендинг или сайт для бизнеса? Напишите на почту — отвечу и обсудим задачу.",
    "contact.email": "Написать на почту",
    "contact.tg": "Telegram",
    "contact.tgnote": "Telegram указан для справки",
    "footer.rights": "Все права защищены",
    "footer.top": "Наверх",
    "modal.open": "Открыть сайт",
    "modal.close": "Закрыть",
  },
  en: {
    "nav.works": "Work",
    "nav.about": "About",
    "nav.contact": "Contact",
    "hero.status": "Open to projects",
    "hero.eyebrow": "Frontend · Web development",
    "hero.role": "Frontend developer",
    "hero.lead": "I build landing pages and business sites in clean HTML, CSS and JavaScript — fast, responsive, nothing extra.",
    "hero.cta1": "View work",
    "hero.cta2": "Write",
    "hero.stat1": "projects in portfolio",
    "hero.stat2": "live sites in production",
    "hero.stat3": "clean stack",
    "works.eyebrow": "Selected projects",
    "works.index": "Index",
    "works.title": "Live sites I have built",
    "works.sub": "Seven live business sites and a series of promo posters for a student party. Click a card to see it larger.",
    "works.open": "Open site",
    "works.view": "View designs",
    "about.eyebrow": "About",
    "about.index": "Profile",
    "about.title": "A few words about the work",
    "about.lead": "I build clean, fast and responsive websites with HTML, CSS and JavaScript — no heavy frameworks, nothing extra.",
    "about.text": "I focus on landing pages and services sites for business: from the idea and structure to markup, animations and publishing on a live domain. I care about typography, load speed and making a site look great on both phone and desktop.",
    "about.spec": "Skills",
    "about.s1": "Markup (HTML / CSS)",
    "about.s2": "JavaScript",
    "about.s3": "Responsive & animation",
    "about.s4": "Publishing & domains",
    "contact.eyebrow": "Contact",
    "contact.title": "Let's build a website",
    "contact.sub": "Need a landing page or a business site? Drop me an email and we'll discuss the task.",
    "contact.email": "Send an email",
    "contact.tg": "Telegram",
    "contact.tgnote": "Telegram is shown for reference",
    "footer.rights": "All rights reserved",
    "footer.top": "Back to top",
    "modal.open": "Open site",
    "modal.close": "Close",
  },
};

const ICON = {
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17 17 7M9 7h8v8"/></svg>',
  expand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>',
};

/* ---------- State ---------- */
const browserLang = String(navigator.language || "ru").toLowerCase().startsWith("en") ? "en" : "ru";
let lang = localStorage.getItem("lang") || browserLang;
if (!["ru", "en"].includes(lang)) lang = "ru";

const t = (key) => (I18N[lang] && I18N[lang][key]) || key;

/* ---------- Render works ---------- */
const hasUrl = (p) => !!p.url && p.url !== "#";
const isGallery = (p) => Array.isArray(p.shots) && p.shots.length > 0;

function shotHTML(p, L) {
  const expand = `<span class="expand" aria-hidden="true">${ICON.expand}</span>`;
  if (isGallery(p)) {
    const idxs = (p.cover || [0, 1, 2]).slice(0, 3);
    const imgs = idxs.map((i) => `<img src="${p.shots[i]}" alt="" loading="lazy">`).join("");
    return `<div class="work-shot collage">${imgs}<span class="count">${p.shots.length} шт.</span>${expand}</div>`;
  }
  return `<div class="work-shot"><img src="${p.shot}" alt="${L.title}" loading="lazy">${expand}</div>`;
}
function renderWorks() {
  const grid = document.getElementById("works-grid");
  grid.innerHTML = PROJECTS.map((p, i) => {
    const L = p[lang];
    const idx = "W " + String(i + 1).padStart(2, "0");
    return `
    <article class="work reveal" data-id="${p.id}" tabindex="0" role="button" aria-label="${L.title}" style="transition-delay:${Math.min(i * 55, 300)}ms">
      <div class="work-top">
        <span class="stamp"><span class="br">[</span> ${L.cat} <span class="br">]</span></span>
        <span class="idx">${idx}</span>
      </div>
      <div>
        <h3 class="work-title">${L.title}</h3>
        <div class="work-owner">${p.owner}</div>
      </div>
      ${shotHTML(p, L)}
      <p class="work-desc">${L.desc}</p>
      <div class="work-foot">
        <div class="tags">${p.tags.map((x) => `<span class="tag">${x}</span>`).join("")}</div>
        ${hasUrl(p)
          ? `<a class="link-open" href="${p.url}" target="_blank" rel="noopener" data-open>${t("works.open")} ${ICON.arrow}</a>`
          : `<span class="link-open">${t("works.view")} ${ICON.arrow}</span>`}
      </div>
    </article>`;
  }).join("");

  grid.querySelectorAll(".work").forEach((card) => {
    const openModal = () => showModal(card.dataset.id);
    card.addEventListener("click", (e) => {
      if (e.target.closest("[data-open]")) return; // let the link work
      openModal();
    });
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openModal(); }
    });
  });
  observeReveal();
}

/* ---------- Modal ---------- */
const modal = document.getElementById("modal");
const modalCard = modal.querySelector(".modal-card");
const modalShot = document.getElementById("modal-shot");
const modalCounter = document.getElementById("modal-counter");

function updateCounter() {
  const imgs = [...modalShot.querySelectorAll(".g-img")];
  if (!imgs.length) return;
  const mid = modalShot.scrollTop + modalShot.clientHeight / 2;
  let best = 0, dist = Infinity;
  imgs.forEach((im, i) => {
    const d = Math.abs(im.offsetTop + im.offsetHeight / 2 - mid);
    if (d < dist) { dist = d; best = i; }
  });
  const pad = (n) => String(n).padStart(2, "0");
  modalCounter.textContent = pad(best + 1) + " / " + pad(imgs.length);
}
modalShot.addEventListener("scroll", updateCounter, { passive: true });

function showModal(id) {
  const p = PROJECTS.find((x) => x.id === id);
  if (!p) return;
  const L = p[lang];
  const gallery = isGallery(p);

  modalCard.classList.toggle("gallery", gallery);
  if (gallery) {
    modalShot.innerHTML = p.shots
      .map((src, i) => `<img class="g-img" src="${src}" alt="${L.title} — ${i + 1}">`)
      .join("");
    modalShot.tabIndex = 0;
    modalCounter.hidden = false;
    modalCounter.textContent = "01 / " + String(p.shots.length).padStart(2, "0");
  } else {
    modalShot.innerHTML = `<img src="${p.shot}" alt="${L.title}">`;
    modalShot.removeAttribute("tabindex");
    modalCounter.hidden = true;
  }

  document.getElementById("modal-cat").innerHTML = `<span class="br">[</span> ${L.cat} <span class="br">]</span>`;
  document.getElementById("modal-title").textContent = L.title;
  document.getElementById("modal-owner").textContent = p.owner;
  document.getElementById("modal-desc").textContent = L.desc;

  const link = document.getElementById("modal-open");
  if (hasUrl(p)) {
    link.href = p.url;
    link.innerHTML = `${t("modal.open")} ${ICON.arrow}`;
    link.hidden = false;
  } else {
    link.hidden = true;
  }

  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  modalShot.scrollTop = 0;
  if (gallery) modalShot.focus({ preventScroll: true }); // стрелки ↑↓ листают сразу
}
function hideModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}
modal.addEventListener("click", (e) => { if (e.target === modal) hideModal(); });
document.getElementById("modal-close").addEventListener("click", hideModal);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && modal.classList.contains("open")) hideModal(); });

/* ---------- i18n apply ---------- */
function applyI18n() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-html]").forEach((el) => { el.innerHTML = t(el.dataset.i18nHtml); });
  const lb = document.getElementById("lang-btn");
  lb.textContent = lang === "ru" ? "EN" : "RU";
  lb.setAttribute("aria-label", lang === "ru" ? "Switch to English" : "Переключить на русский");
}
function setLang(next) {
  lang = next;
  localStorage.setItem("lang", lang);
  applyI18n();
  renderWorks();
}

/* ---------- Theme (dark is the identity default) ---------- */
function setTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("theme", theme);
}
(function initTheme() {
  setTheme(localStorage.getItem("theme") || "dark");
})();

/* ---------- Reveal on scroll ---------- */
let revealObserver;
function observeReveal() {
  if (!revealObserver) {
    revealObserver = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) { en.target.classList.add("in"); revealObserver.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  }
  document.querySelectorAll(".reveal:not(.in)").forEach((el) => revealObserver.observe(el));
}

/* ---------- Skill meters ---------- */
function initSkillBars() {
  const bars = document.querySelectorAll(".meter i");
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (en.isIntersecting) { en.target.style.width = en.target.dataset.val + "%"; io.unobserve(en.target); }
    });
  }, { threshold: 0.4 });
  bars.forEach((b) => io.observe(b));
}

/* ---------- Header shadow on scroll ---------- */
const header = document.querySelector(".topbar");
window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 8);
}, { passive: true });

/* ---------- Boot ---------- */
document.getElementById("theme-toggle").addEventListener("click", () => {
  const cur = document.documentElement.getAttribute("data-theme");
  setTheme(cur === "dark" ? "light" : "dark");
});
document.getElementById("lang-btn").addEventListener("click", () => setLang(lang === "ru" ? "en" : "ru"));

applyI18n();
renderWorks();
initSkillBars();
observeReveal();
